#include <stdio.h>
#include <string.h>

int main(void) {
	// TODO: add your code here

	return 0;
}
