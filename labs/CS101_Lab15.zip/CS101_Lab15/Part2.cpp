#include <stdio.h>

#define WIDTH 20

char choose(int x, int y);

int main(void) {
	for (int j = 0; j < WIDTH; j++) {
		for (int i = 0; i < WIDTH; i++) {
			char c = ' ';
			choose(i, j);
			printf("%c", c);
		}
		printf("\n");
	}

	return 0;
}

char choose(int x, int y) {
	char c = ' ';
	if (x == 0 || x == WIDTH-1) {
		c = '%';
	}
	return c;
}
