#include <stdio.h>

// TODO: add a function prototype here

// IMPORTANT: do not modify the main function in any way
int main(void) {
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 10; i++) {
			char c;
			c = choose(i, j);
			printf("%c", c);
		}
		printf("\n");
	}
	return 0;
}


// TODO: add a function definition here
