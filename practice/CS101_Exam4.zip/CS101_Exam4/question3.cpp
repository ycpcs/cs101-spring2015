#include <stdio.h>
#include <math.h>

struct Point {
	double x, y;
};

struct Circle {
	struct Point center;
	double radius;
};

double distance(const struct Point *p1, const struct Point *p2);
bool is_inside(const struct Point *p, const struct Circle *c);

// IMPORTANT: do not modify the main function in any way
int main(void) {
	struct Point myPoint;
	struct Circle myCircle;

	printf("Point x/y: ");
	scanf("%lf %lf", &myPoint.x, &myPoint.y);
	printf("Circle center x/y: ");
	scanf("%lf %lf", &myCircle.center.x, &myCircle.center.y);
	printf("Circle radius: ");
	scanf("%lf", &myCircle.radius);

	double distance_result = distance(&myPoint, &myCircle.center);
	bool is_inside_result = is_inside(&myPoint, &myCircle);

	printf("distance returned %lf\n", distance_result);
	printf("is_inside returned ");
	if (is_inside_result) {
		printf("true\n");
	} else {
		printf("false\n");
	}
	return 0;
}

// TODO: write definitions for distance and is_inside

