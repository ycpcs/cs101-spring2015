#include <stdio.h>

// You can add function prototypes, but you don't have to

int main(void) {
	// The code to read in the array vaues is provided
	int array1[10];
	int array2[10];

	printf("Enter values for array 1: ");
	for (int i = 0; i < 10; i++) {
		scanf("%i", &array1[i]);
	}
	printf("Enter values for array 2: ");
	for (int i = 0; i < 10; i++) {
		scanf("%i", &array2[i]);
	}

	// TODO: add your code here

	return 0;
}

// You can add function definitions, but you don't have to

