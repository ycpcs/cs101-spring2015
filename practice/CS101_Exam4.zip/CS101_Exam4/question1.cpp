#include <stdio.h>

// TODO: write a prototype for the swap_values function

// IMPORTANT: do not modify the main function in any way
int main(void) {
	int a, b;
	printf("Enter two integers: ");
	scanf("%i %i", &a, &b);

	swap_values(&a, &b);

	printf("After calling swap_values: %i %i\n", a, b);
	return 0;
}

// TODO: write a definition for the swap_values function

