#include <stdio.h>

int main(void) {
	int size;
	printf("Enter size: ");
	scanf("%i", &size);
	if (size % 2 != 1) {
		printf("Size must be odd\n");
		return 1;
	}

	// TODO: add your code here

	return 0;
}
